﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHogaChang
{
    class Issue
    {
        public string Quantity { get; set; }
        public string Price { get; set; }
        public string Author { get; set; }
    }
}
