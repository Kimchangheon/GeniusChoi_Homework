﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms ;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Threading;


namespace MyHogaChang
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
       

        private string Request_Json()
        {
            string result = null;
            string url = "https://api.bithumb.com/public/orderbook";

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream stream = response.GetResponseStream();
                StreamReader reader = new StreamReader(stream);
                result = reader.ReadToEnd();
                stream.Close();
                response.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return result;
        }

        private void ParseJson(String json)
        {
            List<Issue> issues = new List<Issue>();

            JObject obj = JObject.Parse(json);
            
            JArray array = JArray.Parse(obj["data"]["bids"].ToString());
            foreach(JObject itemObj in array)
            {
                Issue issue = new Issue();
                issue.Quantity = itemObj["quantity"].ToString();
                issue.Price = itemObj["price"].ToString();
                //issue.Author = itemObj["author"]["name"].ToString();
                issues.Add(issue);
            }
            for(int i =0; i<issues.Count; i++)
            {
                dataGridView1["quantity", i].Value = issues[i].Quantity;
                dataGridView1["price", i].Value = issues[i].Price;
            }
            

        }

        private void SetupDataGridView()
        {
            this.Controls.Add(dataGridView1);

            dataGridView1.ColumnCount = 2;
            dataGridView1.RowCount = 100;
            dataGridView1.Columns[0].Name = "quantity";
            dataGridView1.Columns[1].Name = "price";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SetupDataGridView();
            ThreadStart ts = new ThreadStart(ThreadBody);
            Thread t = new Thread(ts);
            t.Start();
           
            
        }

        void ThreadBody()
        {
            while(true)
            {
                ParseJson(Request_Json());
                Thread.Sleep(1000);
            }
        }
    }
}
